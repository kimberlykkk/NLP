"""Generate task 2-6 SVG figures from recorded training/evaluation results."""
import html
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
COLORS = ["#2563eb", "#ea580c", "#059669", "#9333ea"]


def read_json(relative_path):
    path = ROOT / relative_path
    if not path.is_file():
        raise FileNotFoundError(f"Required recorded result not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def write_svg(relative_path, body, width, height):
    path = ROOT / relative_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}">\n'
        '<rect width="100%" height="100%" fill="#ffffff"/>\n'
        f"{body}</svg>\n",
        encoding="utf-8",
    )
    print(f"Wrote {path.relative_to(ROOT)}")


def text(x, y, value, size=12, anchor="middle", color="#334155", weight="normal"):
    return (
        f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{anchor}" '
        f'font-family="Segoe UI, Arial, sans-serif" font-size="{size}" '
        f'font-weight="{weight}" fill="{color}">{html.escape(str(value))}</text>\n'
    )


def line_panel(x, y, width, height, title, y_label, series, x_label="Step"):
    values = [value for _, points, _ in series for value in points]
    if not values or any(not math.isfinite(value) for value in values):
        raise ValueError(f"{title}: line data must be non-empty and finite")

    left, right, top, bottom = 62, 20, 42, 48
    plot_left, plot_right = x + left, x + width - right
    plot_top, plot_bottom = y + top, y + height - bottom
    low, high = min(values), max(values)
    pad = (high - low) * 0.08 if high != low else max(abs(low) * 0.08, 0.1)
    low, high = low - pad, high + pad
    body = [text(x + width / 2, y + 22, title, 16, weight="bold")]

    for tick in range(5):
        fraction = tick / 4
        tick_y = plot_bottom - fraction * (plot_bottom - plot_top)
        tick_value = low + fraction * (high - low)
        body.append(
            f'<line x1="{plot_left}" y1="{tick_y:.1f}" x2="{plot_right}" '
            f'y2="{tick_y:.1f}" stroke="#e2e8f0"/>\n'
        )
        body.append(text(plot_left - 8, tick_y + 4, f"{tick_value:.3g}", 10, "end"))

    body.append(
        f'<line x1="{plot_left}" y1="{plot_top}" x2="{plot_left}" '
        f'y2="{plot_bottom}" stroke="#64748b"/>\n'
    )
    body.append(
        f'<line x1="{plot_left}" y1="{plot_bottom}" x2="{plot_right}" '
        f'y2="{plot_bottom}" stroke="#64748b"/>\n'
    )
    max_index = max(len(points) for _, points, _ in series) - 1
    for name, points, color in series:
        coords = []
        for index, value in enumerate(points):
            px = plot_left + (index / max(max_index, 1)) * (plot_right - plot_left)
            py = plot_bottom - ((value - low) / (high - low)) * (plot_bottom - plot_top)
            coords.append(f"{px:.1f},{py:.1f}")
        body.append(
            f'<polyline fill="none" stroke="{color}" stroke-width="2" '
            f'stroke-linejoin="round" stroke-linecap="round" '
            f'points="{" ".join(coords)}"/>\n'
        )

    label_y = y + height - 12
    body.append(text(x + width / 2, label_y, x_label, 11))
    body.append(
        f'<text x="{x + 15}" y="{y + height / 2}" text-anchor="middle" '
        f'transform="rotate(-90 {x + 15} {y + height / 2})" '
        f'font-family="Segoe UI, Arial, sans-serif" font-size="11" '
        f'fill="#334155">{html.escape(y_label)}</text>\n'
    )

    legend_x = plot_left + 8
    for name, _, color in series:
        body.append(
            f'<line x1="{legend_x}" y1="{plot_top - 10}" x2="{legend_x + 18}" '
            f'y2="{plot_top - 10}" stroke="{color}" stroke-width="2"/>\n'
        )
        body.append(text(legend_x + 24, plot_top - 6, name, 10, "start"))
        legend_x += 34 + len(name) * 6
    return "".join(body)


def moving_average(values, window=15):
    return [
        sum(values[max(0, i - window + 1):i + 1])
        / len(values[max(0, i - window + 1):i + 1])
        for i in range(len(values))
    ]


def bar_panel(x, y, width, height, title, items, maximum, value_format):
    if maximum <= 0:
        raise ValueError(f"{title}: maximum must be positive")
    left, right, top, bottom = 180, 45, 45, 25
    plot_width = width - left - right
    row_height = (height - top - bottom) / max(len(items), 1)
    body = [text(x + width / 2, y + 23, title, 16, weight="bold")]

    for index, (label, value, color) in enumerate(items):
        row_y = y + top + index * row_height
        bar_width = max(0, min(value / maximum, 1)) * plot_width
        body.append(text(x + left - 10, row_y + row_height * 0.65, label, 11, "end"))
        body.append(
            f'<rect x="{x + left}" y="{row_y + row_height * 0.25:.1f}" '
            f'width="{bar_width:.1f}" height="{row_height * 0.5:.1f}" '
            f'rx="4" fill="{color}"/>\n'
        )
        body.append(
            text(x + left + bar_width + 8, row_y + row_height * 0.65,
                 value_format(value), 11, "start", weight="bold")
        )
    return "".join(body)


def generate_task2():
    history = read_json("task-2-mini-gpt/history.json")
    train_loss, dev_ppl = history["train_loss"], history["dev_ppl"]
    if not train_loss or len(train_loss) != len(dev_ppl):
        raise ValueError("task2 history must have aligned train_loss and dev_ppl")
    best_epoch = min(range(len(dev_ppl)), key=dev_ppl.__getitem__) + 1
    body = text(470, 28, "Task 2 - Mini-GPT Training History", 18, weight="bold")
    body += line_panel(
        10, 35, 920, 390, "Training loss", "Loss",
        [("train loss", train_loss, COLORS[0])], "Epoch",
    )
    body += line_panel(
        10, 430, 920, 390, "Development perplexity", "Perplexity",
        [("dev perplexity", dev_ppl, COLORS[1])], "Epoch",
    )
    body += text(470, 842, f"{len(dev_ppl)} recorded epochs; best dev perplexity "
                           f"{min(dev_ppl):.2f} at epoch {best_epoch}", 12)
    write_svg("task-2-mini-gpt/figures/training_history.svg", body, 940, 860)


def generate_task3():
    curve = read_json("task-3-sft-dpo/results/dpo_curve.json")
    keys = ("loss", "margin", "win_rate")
    if any(not curve.get(key) for key in keys):
        raise ValueError("task3 DPO curve must contain loss, margin, and win_rate")
    steps = {len(curve[key]) for key in keys}
    if len(steps) != 1:
        raise ValueError("task3 DPO curve arrays must have equal lengths")

    panels = [
        ("DPO loss", "Loss", "loss"),
        ("Policy-reference margin", "Margin", "margin"),
        ("Win rate", "Win rate", "win_rate"),
    ]
    body = text(470, 30, "Task 3 - DPO Training Traces", 18, weight="bold")
    for index, (title, label, key) in enumerate(panels):
        values = curve[key]
        smooth = moving_average(values)
        body += line_panel(
            10, 40 + index * 310, 920, 300, title, label,
            [("raw", values, "#cbd5e1"), ("15-step mean", smooth, COLORS[index])],
        )
    write_svg("task-3-sft-dpo/figures/dpo_training.svg", body, 940, 980)


def generate_task4():
    results = read_json("task-4-rag/eval/result.json")
    recall = next(item for item in results if item.get("test") == "nndl_gold_recall_at_10")
    count = recall["n"]
    metrics = [
        ("Recall@1", recall["recall_at_1"]),
        ("Recall@3", recall["recall_at_3"]),
        ("Recall@5", recall["recall_at_5"]),
        ("Recall@10", recall["recall_at_10"]),
        ("MRR", recall["mrr"]),
    ]
    items = [(name, value, COLORS[i % len(COLORS)])
             for i, (name, value) in enumerate(metrics)]
    body = bar_panel(
        20, 40, 900, 370, "Task 4 - Recorded Retrieval Metrics (0-1)",
        items, 1.0, lambda value: f"{value:.3f}",
    )
    body += text(470, 440, f"Gold QA questions: n={count}; source: eval/result.json", 12)
    write_svg("task-4-rag/figures/retrieval_metrics.svg", body, 940, 470)


def generate_task5():
    results = read_json("task-5-tool-agent/eval/result.json")
    test = next(item for item in results if item.get("test") == "multi_tool_success_rate")
    details = test["details"]
    if not details:
        raise ValueError("task5 multi_tool_success_rate has no case details")
    success_count = sum(bool(item.get("success")) for item in details)
    expected_count = sum(bool(item.get("used_expected_tools")) for item in details)
    total = len(details)
    items = [
        ("Cases passing answer checks", success_count / total, COLORS[0]),
        ("Cases using expected tools", expected_count / total, COLORS[1]),
    ]
    body = bar_panel(
        20, 40, 900, 230, "Task 5 - Recorded Agent Evaluation",
        items, 1.0, lambda value: f"{value:.0%}",
    )
    body += text(
        470, 305,
        f"n={total}; wiki individual test was network-skipped in the recorded run",
        12,
    )
    write_svg("task-5-tool-agent/figures/agent_evaluation.svg", body, 940, 340)


def generate_task6():
    results = read_json("task-6-coding-agent/eval/result.json")
    statuses = [item.get("pass") for item in results]
    counts = {
        "Passed": sum(value is True for value in statuses),
        "Failed": sum(value is False for value in statuses),
        "Skipped": sum(value is None for value in statuses),
    }
    items = [
        (label, count, color)
        for label, count, color in zip(
            counts, counts.values(), [COLORS[2], "#dc2626", "#94a3b8"]
        )
    ]
    body = bar_panel(
        20, 40, 900, 260, "Task 6 - Recorded Coding-Agent Checks",
        items, max(len(results), 1), lambda value: f"{int(value)}",
    )
    body += text(470, 330, f"Checks recorded: {len(results)}; skipped checks are not failures", 12)
    write_svg("task-6-coding-agent/figures/coding_agent_checks.svg", body, 940, 365)


def main():
    for generate in (generate_task2, generate_task3, generate_task4,
                     generate_task5, generate_task6):
        generate()


if __name__ == "__main__":
    main()
